import { useAdmin } from "../../context/AdminContext";

export default function AdminCustomers() {
  const { customers } = useAdmin();

  return (
    <div>
      <div className="mb-8">
        <h2 className="font-display text-3xl font-light text-obsidian mb-2">Customers</h2>
        <p className="text-slate font-body text-sm">{customers.length} registered customers</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {customers.map((customer) => (
          <div
            key={customer.id}
            className="bg-white border border-gold/10 p-6 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center">
                <span className="font-display text-lg text-gold-dark">
                  {customer.name.charAt(0)}
                </span>
              </div>
              <div>
                <h3 className="font-display text-lg text-obsidian">{customer.name}</h3>
                <p className="text-xs text-slate font-body">{customer.email}</p>
              </div>
            </div>
            <div className="space-y-2 text-sm font-body">
              <div className="flex justify-between">
                <span className="text-slate/60">Phone</span>
                <span className="text-obsidian">{customer.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate/60">Orders</span>
                <span className="text-obsidian">{customer.orders}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate/60">Total Spent</span>
                <span className="text-gold-dark font-medium">{customer.spent}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate/60">Joined</span>
                <span className="text-obsidian">{customer.joined}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
