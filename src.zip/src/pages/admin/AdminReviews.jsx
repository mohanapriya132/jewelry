import { useAdmin } from "../../context/AdminContext";

const statusColors = {
  Approved: "bg-green-100 text-green-800",
  Pending: "bg-yellow-100 text-yellow-800",
  Rejected: "bg-red-100 text-red-800",
};

export default function AdminReviews() {
  const { reviews, updateReviewStatus, deleteReview } = useAdmin();

  return (
    <div>
      <div className="mb-8">
        <h2 className="font-display text-3xl font-light text-obsidian mb-2">Reviews</h2>
        <p className="text-slate font-body text-sm">{reviews.length} customer reviews</p>
      </div>

      <div className="space-y-4">
        {reviews.map((review) => (
          <div
            key={review.id}
            className="bg-white border border-gold/10 p-6 shadow-sm"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-3">
              <div>
                <h3 className="font-display text-lg text-obsidian">{review.product}</h3>
                <p className="text-xs text-slate font-body">
                  {review.customer} · {review.date}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={review.status}
                  onChange={(e) => updateReviewStatus(review.id, e.target.value)}
                  className={`text-xs px-2 py-1 rounded border-0 outline-none cursor-pointer ${statusColors[review.status]}`}
                >
                  {["Pending", "Approved", "Rejected"].map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => {
                    if (window.confirm("Delete this review?")) deleteReview(review.id);
                  }}
                  className="text-xs text-red-600 hover:text-red-800 font-body px-2"
                >
                  Delete
                </button>
              </div>
            </div>
            <div className="flex items-center gap-1 mb-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <svg
                  key={i}
                  className={`w-4 h-4 ${i < review.rating ? "fill-gold text-gold" : "fill-none text-slate/30"}`}
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
              ))}
            </div>
            <p className="text-sm text-slate font-body leading-relaxed">{review.comment}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
