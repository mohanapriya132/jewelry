import { useAdmin } from "../../context/AdminContext";

const statusOptions = ["Pending", "Processing", "Shipped", "Delivered"];

const statusColors = {
  Delivered: "bg-green-100 text-green-800",
  Shipped: "bg-blue-100 text-blue-800",
  Processing: "bg-yellow-100 text-yellow-800",
  Pending: "bg-gray-100 text-gray-800",
};

export default function AdminOrders() {
  const { orders, updateOrderStatus } = useAdmin();

  return (
    <div>
      <div className="mb-8">
        <h2 className="font-display text-3xl font-light text-obsidian mb-2">Orders</h2>
        <p className="text-slate font-body text-sm">{orders.length} total orders</p>
      </div>

      <div className="bg-white border border-gold/10 shadow-sm overflow-x-auto">
        <table className="w-full text-sm font-body">
          <thead>
            <tr className="border-b border-gold/10 text-left text-slate/60">
              <th className="p-4 font-medium">Order ID</th>
              <th className="p-4 font-medium">Customer</th>
              <th className="p-4 font-medium">Email</th>
              <th className="p-4 font-medium">Items</th>
              <th className="p-4 font-medium">Total</th>
              <th className="p-4 font-medium">Date</th>
              <th className="p-4 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b border-gold/5 hover:bg-mist/50">
                <td className="p-4 text-obsidian font-medium">{order.id}</td>
                <td className="p-4 text-slate">{order.customer}</td>
                <td className="p-4 text-slate">{order.email}</td>
                <td className="p-4 text-slate">{order.items}</td>
                <td className="p-4 text-obsidian">{order.total}</td>
                <td className="p-4 text-slate">{order.date}</td>
                <td className="p-4">
                  <select
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                    className={`text-xs px-2 py-1 rounded border-0 outline-none cursor-pointer ${statusColors[order.status]}`}
                  >
                    {statusOptions.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
