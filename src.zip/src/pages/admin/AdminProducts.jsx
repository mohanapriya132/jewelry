import { useState } from "react";
import { useProducts } from "../../context/ProductContext";
import { CATEGORIES, badgeColor } from "../../data/products";

const emptyProduct = {
  name: "",
  category: "Rings",
  tag: "Rings",
  price: "",
  original: "",
  rating: 5,
  reviews: 0,
  image: "",
  badge: "New",
  description: "",
  features: [],
};

export default function AdminProducts() {
  const { products, addProduct, updateProduct, deleteProduct } = useProducts();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyProduct);
  const [showForm, setShowForm] = useState(false);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyProduct);
    setShowForm(true);
  };

  const openEdit = (product) => {
    setEditing(product.id);
    setForm({ ...product, original: product.original || "" });
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      tag: form.category,
      original: form.original || null,
      rating: Number(form.rating),
      reviews: Number(form.reviews),
    };
    if (editing) {
      updateProduct(editing, payload);
    } else {
      addProduct(payload);
    }
    setShowForm(false);
    setForm(emptyProduct);
    setEditing(null);
  };

  const handleDelete = (id) => {
    if (window.confirm("Delete this product?")) {
      deleteProduct(id);
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h2 className="font-display text-3xl font-light text-obsidian mb-2">Products</h2>
          <p className="text-slate font-body text-sm">{products.length} products in catalogue</p>
        </div>
        <button
          onClick={openCreate}
          className="bg-obsidian text-ivory text-xs tracking-widest uppercase px-6 py-3 hover:bg-gold hover:text-obsidian transition-colors font-body"
        >
          Add Product
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmit}
            className="bg-white w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 shadow-xl"
          >
            <h3 className="font-display text-xl text-obsidian mb-6">
              {editing ? "Edit Product" : "New Product"}
            </h3>
            <div className="space-y-4">
              {[
                { key: "name", label: "Name" },
                { key: "price", label: "Price (e.g. ₹1,24,999)" },
                { key: "original", label: "Original Price (optional)" },
                { key: "image", label: "Image URL" },
                { key: "description", label: "Description" },
              ].map(({ key, label }) => (
                <div key={key}>
                  <label className="block text-[10px] tracking-widest uppercase text-slate/60 font-body mb-1">
                    {label}
                  </label>
                  <input
                    type="text"
                    value={form[key]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                    required={key !== "original"}
                    className="w-full border border-gold/20 px-3 py-2 text-sm font-body outline-none focus:border-gold"
                  />
                </div>
              ))}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-widest uppercase text-slate/60 font-body mb-1">
                    Category
                  </label>
                  <select
                    value={form.category}
                    onChange={(e) =>
                      setForm({ ...form, category: e.target.value, tag: e.target.value })
                    }
                    className="w-full border border-gold/20 px-3 py-2 text-sm font-body outline-none focus:border-gold"
                  >
                    {CATEGORIES.filter((c) => c !== "All").map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] tracking-widest uppercase text-slate/60 font-body mb-1">
                    Badge
                  </label>
                  <select
                    value={form.badge}
                    onChange={(e) => setForm({ ...form, badge: e.target.value })}
                    className="w-full border border-gold/20 px-3 py-2 text-sm font-body outline-none focus:border-gold"
                  >
                    {["Bestseller", "New", "Sale", "Exclusive"].map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                type="submit"
                className="flex-1 bg-obsidian text-ivory text-xs tracking-widest uppercase py-3 hover:bg-gold hover:text-obsidian transition-colors font-body"
              >
                {editing ? "Update" : "Create"}
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="flex-1 border border-obsidian/20 text-obsidian text-xs tracking-widest uppercase py-3 hover:bg-mist transition-colors font-body"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white border border-gold/10 shadow-sm overflow-x-auto">
        <table className="w-full text-sm font-body">
          <thead>
            <tr className="border-b border-gold/10 text-left text-slate/60">
              <th className="p-4 font-medium">Product</th>
              <th className="p-4 font-medium">Category</th>
              <th className="p-4 font-medium">Price</th>
              <th className="p-4 font-medium">Badge</th>
              <th className="p-4 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id} className="border-b border-gold/5 hover:bg-mist/50">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-10 h-10 object-cover"
                    />
                    <span className="text-obsidian">{product.name}</span>
                  </div>
                </td>
                <td className="p-4 text-slate">{product.category}</td>
                <td className="p-4 text-obsidian">{product.price}</td>
                <td className="p-4">
                  <span
                    className={`text-[9px] tracking-widest uppercase px-2 py-1 ${badgeColor[product.badge] || "bg-obsidian text-ivory"}`}
                  >
                    {product.badge}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <button
                      onClick={() => openEdit(product)}
                      className="text-xs text-gold hover:text-gold-dark font-body"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(product.id)}
                      className="text-xs text-red-600 hover:text-red-800 font-body"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
