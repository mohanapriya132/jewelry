import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { products as initialProducts } from "../data/products";
import { loadFromStorage, saveToStorage } from "../utils/storage";

const ProductContext = createContext();

export function useProducts() {
  return useContext(ProductContext);
}

export function ProductProvider({ children }) {
  const [products, setProducts] = useState(() =>
    loadFromStorage("products", initialProducts)
  );

  useEffect(() => {
    saveToStorage("products", products);
  }, [products]);

  const addProduct = (product) => {
    const newId = Math.max(0, ...products.map((p) => p.id)) + 1;
    setProducts((prev) => [...prev, { ...product, id: newId }]);
  };

  const updateProduct = (id, updates) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deleteProduct = (id) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const getProductById = useCallback(
    (id) => products.find((p) => p.id === Number(id)),
    [products]
  );

  const searchProducts = useCallback(
    (query, category = "All") => {
      const term = query.trim().toLowerCase();
      return products.filter((p) => {
        const matchesCategory =
          category === "All" || p.tag === category || p.category === category;
        const matchesSearch =
          !term ||
          p.name.toLowerCase().includes(term) ||
          p.category.toLowerCase().includes(term) ||
          p.tag.toLowerCase().includes(term);
        return matchesCategory && matchesSearch;
      });
    },
    [products]
  );

  return (
    <ProductContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        getProductById,
        searchProducts,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}
