import { createContext, useContext, useState, useEffect } from "react";
import { loadFromStorage, saveToStorage } from "../utils/storage";
import {
  initialOrders,
  initialCustomers,
  initialReviews,
  ADMIN_CREDENTIALS,
} from "../data/adminData";

const AdminContext = createContext();

export function useAdmin() {
  return useContext(AdminContext);
}

export function AdminProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(
    () => localStorage.getItem("adminAuth") === "true"
  );
  const [orders, setOrders] = useState(() =>
    loadFromStorage("adminOrders", initialOrders)
  );
  const [customers, setCustomers] = useState(() =>
    loadFromStorage("adminCustomers", initialCustomers)
  );
  const [reviews, setReviews] = useState(() =>
    loadFromStorage("adminReviews", initialReviews)
  );

  useEffect(() => {
    saveToStorage("adminOrders", orders);
  }, [orders]);

  useEffect(() => {
    saveToStorage("adminCustomers", customers);
  }, [customers]);

  useEffect(() => {
    saveToStorage("adminReviews", reviews);
  }, [reviews]);

  const login = (email, password) => {
    if (
      email === ADMIN_CREDENTIALS.email &&
      password === ADMIN_CREDENTIALS.password
    ) {
      localStorage.setItem("adminAuth", "true");
      setIsAuthenticated(true);
      return { success: true };
    }
    return { success: false, error: "Invalid email or password" };
  };

  const logout = () => {
    localStorage.removeItem("adminAuth");
    setIsAuthenticated(false);
  };

  const updateOrderStatus = (orderId, status) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
  };

  const updateReviewStatus = (reviewId, status) => {
    setReviews((prev) =>
      prev.map((r) => (r.id === reviewId ? { ...r, status } : r))
    );
  };

  const deleteReview = (reviewId) => {
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
  };

  return (
    <AdminContext.Provider
      value={{
        isAuthenticated,
        login,
        logout,
        orders,
        customers,
        reviews,
        updateOrderStatus,
        updateReviewStatus,
        deleteReview,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}
