import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./index.css";
import { supabase } from "./supabaseClient";
import Home from "./pages/Home";
import WeddingCollectionPage from "./pages/WeddingCollectionPage";
import ProductDetails from "./pages/ProductDetails";
import ContactUs from "./pages/ContactUs";
import Wishlist from "./pages/Wishlist";
import Cart from "./pages/Cart";
import Search from "./pages/Search";
import CustomJewelry from "./pages/CustomJewelry";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminCustomers from "./pages/admin/AdminCustomers";
import AdminReviews from "./pages/admin/AdminReviews";
import AdminLayout from "./components/admin/AdminLayout";
import ProtectedRoute from "./routes/ProtectedRoute";
import { ProductProvider } from "./context/ProductContext";
import { AdminProvider } from "./context/AdminContext";
import { ShopProvider } from "./context/ShopContext";

function App() {
  useEffect(() => {
    const fetchProducts = async () => {
      const { data, error } = await supabase.from("products").select("*");
      if (error) {
        console.error("Error fetching products:", error);
      } else {
        console.log("Fetched products:", data);
      }
    };
    
    fetchProducts();
  }, []);

  return (
    <ProductProvider>
      <AdminProvider>
        <ShopProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/collections/wedding" element={<WeddingCollectionPage />} />
              <Route path="/product/:id" element={<ProductDetails />} />
              <Route path="/contact" element={<ContactUs />} />
              <Route path="/wishlist" element={<Wishlist />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/search" element={<Search />} />
              <Route path="/custom-jewelry" element={<CustomJewelry />} />

              <Route path="/admin/login" element={<AdminLogin />} />
              <Route
                path="/admin"
                element={
                  <ProtectedRoute>
                    <AdminLayout />
                  </ProtectedRoute>
                }
              >
                <Route index element={<AdminDashboard />} />
                <Route path="products" element={<AdminProducts />} />
                <Route path="orders" element={<AdminOrders />} />
                <Route path="customers" element={<AdminCustomers />} />
                <Route path="reviews" element={<AdminReviews />} />
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </ShopProvider>
      </AdminProvider>
    </ProductProvider>
  );
}

export default App;
